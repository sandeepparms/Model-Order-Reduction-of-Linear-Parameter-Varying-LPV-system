% #########################################################################
% TUHH :: Institute for Control Systems :: LPV control
% #########################################################################
% LPV Tools Introduction
%
% Copyright Herbert Werner and Hamburg University of Technology, 2014
% #########################################################################


%% Initialization
clc;clear all;close all
thisdate = datestr(now, 'yyyy-mm-dd_HH-MM');

%% 1. PGRID: Real parameter defined on a grid of points

% Create a PGRID object
rho = pgrid('rho',0.1:0.1:1)

class(rho)
properties(rho)

% Change name
rho.Name = 'x'

% PGRIDs can be used to represent time-varying parameters
% with specified rate bounds
rho = pgrid('rho',0.1:0.1:1,[-0.34 0.34])

% Change Rate Bounds
rho.RateBounds = [-0.34 0.34]



%Mathematical operations on a PGRID return PMAT
crho = cos(rho)

% Plot PMATs vs. parameter
lpvplot(1*rho,'b',crho,'r',rho*crho,'k')

% Maximum over parameter grid
lmax = lpvmax( 1*rho*crho)

class(lmax)
double(lmax)


%% PMAT Matrix function of real parameter

% Horizontal and vertical concatenation to build matrices
x = pgrid('x', linspace(0,10,30) )
M = [x^2 cos(x); -2 sin(x)]

% Plot elements vs. parameter
 rcplot(M)
 
% matrix size and subs_reference work as usual
size(M)
size(M.Domain)
M(:,1)


% Matrix operations handle multiple parameters
M1 = M(1,:)
M2 = [crho rho^2]
M3 = M1+M2

size(M3.Domain)

% Obtain sturcture with all parameters
M3.Parameter

% Go further down to the individual Parameter
M3.Parameter.x.Range
M3.Parameter.rho.RateBounds

% RGRID Rectangular grid of points defined by PGRIDs
x = pgrid('x', linspace(0,10,5) )
y = pgrid('y', linspace(0,1,3) )
r = rgrid(x,y)
size(r)

% Create Gridded Data
Data = rand(2,2,5,3)
D = pmat(Data,r)

% Extract by index
Data(:,:,3,2)
DI = lpvsplit(D,'x',3,'y',2,'index')

% Extract by range
DR = lpvsplit(D,'x',[3 7],'y',[0 0.5])

% Extract by value
DV = lpvsplit(D,'x',5,'y',0,'value')

% Interpolate data in between grid points
Dint = lpvinterp(D,'x',4,'y',0.2)

%% PSS: Parameter-varying state space models
% create from data
sysData = rss(5,2,2,5,3)
sys = pss(sysData,r)


% or build models from PGRID objects
A = -1;
B = 1;
C = 1*rho;
D = 0;
G = ss(A,B,C,D);

% behaves virtually the same as PMAT

%% POINTWISE CALCULATIONS
% many control systems tools are overloaded

% Plot pointwise Frequency response
figure
bode(G)
% Plot pointwise Step Response
figure
step(G)
% Plot pointwise Nyquist Plot
figure
nyquist(G)

% calculate pointwise Hinf norm
n = norm(G,inf)

% Find peak Hinf over Domain
lpvmax(n)

%% LPV CALCULATIONS

% Define Parameter Trajectory
ptraj.time = linspace(0,20,100)
ptraj.rho  = 0.5 + 0.2*sin(ptraj.time)
lpvstep(G,ptraj)

%Bound induced L2 norm
lpvnorm(G)


%% controller synthesis

%define basis functions
Xbasis(1) = basis(1,0); %P0
Xbasis(2) = basis(sin(x)+cos(y),'x',cos(x),'y',-sin(y)); %P1
Xbasis(3) = basis(x^2+2*y,'x',2*x,'y',2); %P2
Xbasis(4) = basis(x*y,'x',y,'y',x); %P3

Ybasis = Xbasis;

%State feedback synthesis
lpvsfsyn(P,ncont,Xbasis)

%Synthesize output feedback LPV controller
lpvsyn(P,nmeas,ncont,Xbasis,Ybasis)


